using UnityEngine;

public class TurnStrategy : MonoBehaviour, IMovable
{
    public float Speed => throw new System.NotImplementedException();

    public void Move(Vector3 direction)
    {
        throw new System.NotImplementedException();
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
